import React from "react";
import { HeadingText, NerdGraphQuery, Spinner, Tabs, TabsItem } from "nr1";

import {
  Table,
  TableHeader,
  TableHeaderCell,
  TableRow,
  TableRowCell,
} from "nr1";

import Entities from "./components/Entities";

import {SCHEMA, TAG_SCHEMA_ENFORCEMENT} from './utils/tag-schema'

import { mandatoryTagRules, optionalTagRules } from "./utils/tag-schema"; // SK

// import Overview from './components/overview'
// import TagCoverageView from './components/tag-coverage'
// import SchemaEditor from './components/schema-editor'

export default class TagVisualizer extends React.Component {
  state = {
    tagHierarchy: [], // SK -- {},
    entityCount: 0,
    loadedEntities: 0,
    doneLoading: false,
    loadError: undefined,
    queryCursor: undefined,
    entityTypes: ["APM", "MOBILE", "BROWSER", "INFRA"],
 };

  static config = {
    hasTagFilterBar: false,
    timePicker: {
      isEnabled: false,
    },
  };

  componentDidMount() {
    this.startLoadingEntityTags();
  }

  render() {
    const {doneLoading, entityCount, loadedEntities, tagHierarchy} = this.state
    // const { doneLoading, entityCount, loadedEntities, entities } = this.state; // SK
    const entities = tagHierarchy // SK

    if (entityCount < 1 || loadedEntities < 1) {
      if (doneLoading) {
        return (
          <HeadingText type={HeadingText.TYPE.HEADING_3}>
            No tags / entities could be loaded.
          </HeadingText>
        );
      } else {
        return <Spinner />;
      }
    }

    // const entityData = JSON.stringify(tagHierarchy)
    return (
      <>
        {doneLoading ? null : (
          <HeadingText type={HeadingText.TYPE.HEADING_4}>
            Loading tags... ({loadedEntities} / {entityCount} entities examined)
          </HeadingText>
        )}
        <div>
          <h1> Entities</h1>
          <Entities
            tagHierarchy={tagHierarchy}
            entityCount={entityCount}
            loadedEntities={loadedEntities}
            doneLoading={doneLoading}
            mandatoryTags={this.state.mandatoryTags}
          />
        </div>
      </>
    );
  }

  /**
   * Loading the tagset for all entities is a bit of a chore.
   *
   * The code below implements a progressive loader that handles the paginated entity query api,
   * unpacking tags from each entity, and building a global tag histogram.
   */
  startLoadingEntityTags = () => {
    // reset all cached state and then fetch the first page of entity results...
    const { loadEntityBatch } = this;

    this.setState(
      {
        tagHierarchy: [], // SK -- {},
        entityCount: 0,
        loadedEntities: 0,
        doneLoading: false,
        loadError: undefined,
        queryCursor: undefined,
      },
      () => {
        loadEntityBatch();
      }
    );
  };

  loadEntityBatch = () => {
    const {
      processEntityQueryResults,
      state: { queryCursor },
    } = this;

    const query = `
    query EntitiesSearchQuery($queryString: String!, $nextCursor: String) {
      actor {
        entitySearch(query: $queryString) {
          count
          results(cursor: $nextCursor) {
            entities {
              account {
                id
                name
              }
              name
              domain
              entityType
              guid
              tags {
                tagKey: key
                tagValues: values
              }
            }
            nextCursor
          }
        }
      }
    }
    `;
    const variables = {
      queryString: "domain in ('APM', 'MOBILE', 'BROWSER')",
    };
    if (queryCursor) {
      variables.nextCursor = queryCursor;
    }

    NerdGraphQuery.query({
      query,
      variables,
    })
      .then(({ loading, data, errors }) => {
        if (data) {
          processEntityQueryResults(data);
        } else {
          console.log("data is NOT truthy", data);
        }
        if (errors) {
          console.log("Entity query error", errors);
        }
      })
      .catch((err) => {
        this.setState({ loadError: err.toString() });
      });
  };

  processEntityQueryResults = (data) => {
    const {
      loadEntityBatch,
      setState,
      state: { loadedEntities, tagHierarchy },
    } = this;

    let entityCount = 0;
    let entities = [];
    let nextCursor = undefined;
    try {
      entityCount = data.actor.entitySearch.count;
      entities = data.actor.entitySearch.results.entities || [];
      nextCursor = data.actor.entitySearch.results.nextCursor || undefined;
    } catch (err) {
      console.log("Error parsing results", err);
    }
    this.processLoadedEntities(entities); // SK

    this.setState(
      {
        queryCursor: nextCursor,
        entityCount,
        loadedEntities: loadedEntities + entities.length,
        doneLoading: !nextCursor,
      },
      () => {
        if (nextCursor) {
          loadEntityBatch();
        }
      }
    );
  };

  processLoadedEntities = (entities) => {
    const { tagHierarchy } = this.state;

    const ee = []
    entities.forEach((entity) => {
      // get all the tags
      const { tags } = entity;
      entity.mandatoryTags = [];
      entity.optionalTags = [];

      // for each tag, if it doesn't make an empty object
      tags.forEach(({ tagKey, tagValues }) => {
        mandatoryTagRules.forEach((rule) => {
          if (rule.key === tagKey) {
            entity.mandatoryTags.push(tagKey);
            return;
          }
        });
        optionalTagRules.forEach((rule) => {
          if (rule.key === tagKey) {
            entity.optionalTags.push(tagKey);
            return;
          }
        });
      });
      tagHierarchy.push(entity)
    });

    return tagHierarchy;
  };

}
