import React, { Component } from "react";

import Entity from "./Entity";

class Entities extends Component {
  render() {
    return (
      <div>
          {this.props.tagHierarchy.map((entity) => (
            <Entity key={entity.guid} entity={entity}/>
          ))}
      </div>
    );
  }
}

export default Entities;
