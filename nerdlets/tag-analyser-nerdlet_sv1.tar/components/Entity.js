import React, { Component } from "react";

// import { checkPropTypes } from 'prop-types';

// import classes from "./Entity.css";

class Entity extends Component {
  //   componentDidMount() {
  //     const  { mandatoryTags } = this.props
  //     const entityMandatoryTags = this.props.entity.tags.filter(function(tag, index, arr) {
  //         return mandatoryTags.includes(tag.tagKey)
  //     })
  //     this.setState({entityMandatoryTags: entityMandatoryTags})
  //   }

  render() {
    // const { entityMandatoryTags } = this.state
    return (
      <div className="split" style={{ border: "6px solid #eee" }}>
        <div
          className="left"
          style={{
            border: "1px solid #eee",
            boxShadow: "0 2px 3px #ccc",
            padding: "10px",
            margin: "10px auto",
            boxSizing: "border-box",
          }}
        >
          <ul>
            <li style={{ textIndent: "10px" }}>
              <label>Account</label>
            </li>
            <li style={{ textIndent: "30px" }}>
              <label>
                Id: <strong>{this.props.entity.account.id}</strong>
              </label>{" "}
            </li>
            <li style={{ textIndent: "30px" }}>
              <label>
                Name: <strong>{this.props.entity.account.name}</strong>
              </label>
            </li>
            <li style={{ textIndent: "10px" }}>
              Domain: <strong>{this.props.entity.domain}</strong>
            </li>
            <li style={{ textIndent: "10px" }}>
              <label>Entity</label>
            </li>
            {/* <li style={{ textIndent: "30px" }}>
              Id: <strong>{this.props.entity.guid}</strong>
            </li> */}
            <li style={{ textIndent: "30px" }}>
              Type: <strong>{this.props.entity.entityType}</strong>
            </li>
            <li style={{ textIndent: "30px" }}>
              Name: <strong>{this.props.entity.name}</strong>
            </li>
          </ul>
        </div>

        <div className="right">
          <div>
            <h1>Mandatory Tags</h1>
            <div
              style={{
                display: "flex",
                flexFlow: "row wrap",
                margin: "7px 4px",
              }}
            >
              {this.props.entity.tags.map((tag) => {
                return this.props.entity.mandatoryTags.includes(tag.tagKey) ? (
                  <div
                    style={{
                      fontSize: "16px",
                      fontWeight: "bold",
                      border: "4px solid black",
                      // marginRight: "15px",
                      // marginBottom: "15px",
                      margin: "15px 15px",
                      padding: "8px",
                      color: "navajowhite",
                      backgroundColor: "green",
                    }}
                    key={this.props.entity.guid + "_" + tag.tagKey}
                  >
                    <span>
                        <img src="../images/nerdlets/tag-analyser-nerdlet/images/hand-drawn-green-checkmark-ok-and-red-x-vector-22551880.jpg"></img>
                        {tag.tagKey + ": " + tag.tagValues.join(", ")}
                    </span>
                  </div>
                ) : (
                  <div
                    style={{
                      fontSize: "16px",
                      fontWeight: "bold",
                      border: "4px solid black",
                      // marginRight: "15px",
                      // marginBottom: "10px",
                      margin: "15px 15px",
                      padding: "5px",
                      color: "navajowhite",
                      backgroundColor: "red",
                    }}
                    key={this.props.entity.guid + "_" + tag.tagKey}
                  >
                    {tag.tagKey + ": Missing"}
                  </div>
                );
              })}
            </div>

            <hr></hr>

            <h1>Optional Tags</h1>
            <div
              style={{
                display: "flex",
                flexFlow: "row wrap",
                margin: "7px 4px",
              }}
            >
              {this.props.entity.tags.map((tag) => {
                return this.props.entity.optionalTags.includes(tag.tagKey) ? (
                  <div
                    style={{
                      fontSize: "16px",
                      fontWeight: "bold",
                      border: "4px solid black",
                      // marginRight: "15px",
                      // marginBottom: "15px",
                      margin: "15px 15px",
                      padding: "5px",
                      color: "navajowhite",
                      backgroundColor: "green",
                    }}
                    key={this.props.entity.guid + "_" + tag.tagKey}
                  >
                    <span>{tag.tagKey + ": " + tag.tagValues.join(", ")}</span>
                  </div>
                ) : (
                  <div
                    style={{
                      fontSize: "16px",
                      fontWeight: "bold",
                      border: "4px solid black",
                      // marginRight: "15px",
                      // marginBottom: "15px",
                      margin: "15px 15px",
                      padding: "5px",
                      color: "navajowhite",
                      backgroundColor: "red",
                    }}
                    key={this.props.entity.guid + "_" + tag.tagKey}
                  >
                    {tag.tagKey + ": Missing"}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Entity;
